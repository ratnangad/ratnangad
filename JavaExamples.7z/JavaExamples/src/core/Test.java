package core;

public class Test {
	int bl;
	public static void main(String[] args) {
		Test t = new Test();
		int ca$h = 10; //$ sign is allowed as variable;
		char ch = 97; 	// We can specify that integral literal either in decimal or octal or hexadecimal form but
						//allowed values range is 0 to 65535.
		char ch1='\u0061'; // hexadecimal values allowed as CHAR
		double d = 123_45.7_5; //_ allowed between values
		int [][]a;  // Two dimensional array array declaration
		int b[][];  // Two dimensional array array declaration
		int[] c[]; // Two dimensional array array declaration
		int[][] e; // Two dimensional array array declaration
		
		System.out.println(d);
		t.methodVarArg("test",10,20,30,40);
		
		int x = 'a';
		System.out.println("Values of x is " +x);
		
		
	}
	
	public void methodVarArg( String str, int ...x) {
		System.out.println("String is : "+ str);
		for(int a: x) {
			System.out.println("Numbers are : "+a);
		}
	}

}
