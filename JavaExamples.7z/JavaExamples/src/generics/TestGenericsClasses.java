package generics;

public class TestGenericsClasses<T, E> {
	/*private T t;
	private E e;*/
	   public void add(T t, E e) {
	     System.out.println(t);
	     System.out.println(e);
	   }


	   public static void main(String[] args) {
		   TestGenericsClasses<Integer, Integer> integerBox = new TestGenericsClasses<Integer, Integer>();
		   TestGenericsClasses<String, String> stringBox = new TestGenericsClasses<String, String>();
	    
	      integerBox.add(new Integer(10), new Integer(5));
	      stringBox.add(new String("Hello "), new String("World"));
	   }
}
