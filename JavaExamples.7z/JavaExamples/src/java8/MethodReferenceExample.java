package java8;

interface Calculate {
	void calculate(int a, int b);
}

class Calc {
	public void addition(int i, int j) {
		System.out.println("Addition is " + (i+j));
	}
	
	public void xyz(int i, int j) {
		System.out.println("printing is " + (i+j));
	}
}

interface Messageger {
	Message getMessage(String str);
}

class Message {
	public Message(String str) {
		System.out.println("Message is :" + str);
	}
}

public class MethodReferenceExample {
	public static void main(String args[]) {
		Calc cal = new Calc();
		/*Calculate calculate = (a,b)->{
			cal.addition(a, b);
			//cal.xyz(a, b);
		};*/
		
		Calculate calculate = cal::addition;
		calculate.calculate(10, 20); //Method reference
		
		Messageger messageger = Message::new; //Constructor reference
		messageger.getMessage("New Meaage");
		
	}
	
}
