package java8;

public class fibonacci {

	public static void main(String[] args) {
		int num = 1;
		int sum = 1;
		int cal = 0;
		System.out.println(num);
		for(int i=0; i<=5; i++) {
			sum = cal + num;
			System.out.println(sum);
			cal = num;	
			num = sum;
		}
	}
	
	
	public void calFibo(int num) {
		if(num >100 ) return;
		System.out.println(num);
		//num = num + calFibo(num);
	}

}
