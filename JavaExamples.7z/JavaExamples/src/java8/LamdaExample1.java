package java8;

@FunctionalInterface
interface Functional { // Functional interface without parameter
	void calSum();
	default void calSum1() {
		System.out.println(5+5);
	}
 }

interface Functional2 { // Functional interface without parameter
	void calSum(int i, int j);
}

interface Functional3 { // Functional interface with return value
	int calSum(int i, int j);
}

public class LamdaExample1 {
	public static void main(String[] args) {
		//
		Functional functional = () -> System.out.println("Calling Functional interface");
		functional.calSum();
	
	Functional2 functional2 = (i, j) -> System.out.println("Addition is " + (i+j));
	functional2.calSum(15,10);
	
	Functional3 functional3 = (i, j) -> {
		return i+j;
	};
	System.out.println("Addition is " + functional3.calSum(5,10));
	}
}
