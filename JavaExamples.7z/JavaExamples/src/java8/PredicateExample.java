package java8;

import java.util.List;
import java.util.function.BiPredicate;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class PredicateExample {
	
	static Predicate<Student> studentHeight = s -> (s.getHeight()>150);
	static Predicate<Student> studentGender = s -> (s.getGender().equals("male"));
	static BiPredicate<Integer, String> biPredicate = (height, gender) -> height > 160 && gender.equals("male");

	public static void main(String[] args) {
		List<Student> students = StudentsRepository.getAllStudents();
		System.out.println(studentHeight.test(students.get(1)));
		System.out.println("****************************************");
		
//		students.forEach(s -> {
//			if(studentHeight.and(studentGender).test(s)) {
//				System.out.println(s);
//			}
//		});
		
//		students.forEach(s -> {
//			if(biPredicate.test(s.getHeight(), s.getGender())) {
//				System.out.println(s);
//			}
//		});
			
		Consumer<Student> s1 = s -> {
			if(biPredicate.test(s.getHeight(), s.getGender())) {
				System.out.println(s);
			}
		};
		
		List<Student> maleStudents = students.stream().filter(s -> biPredicate.test(s.getHeight(), s.getGender())).collect(Collectors.toList());
		System.out.println(maleStudents);
		
	}

}
