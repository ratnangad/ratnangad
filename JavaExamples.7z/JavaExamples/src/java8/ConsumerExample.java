package java8;

import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

public class ConsumerExample {
	static Consumer<Student> studentInfo = s -> System.out.println(s);
	static Consumer<Student> studentFirstName = s -> System.out.println(s.getFirstName().toUpperCase());
	static Consumer<Student> studentAge = s -> System.out.println(s.getFirstName() + " : "+ s.getAge());
	
	static BiConsumer<String, Integer> studentsInfo = (s,a) -> System.out.println(s+" : " +a); //Bi Consumer Example.
	
	static void pritStudentName() {
		List<Student> list1 = StudentsRepository.getAllStudents();
		list1.forEach(studentFirstName);
	}
	
	static void pritStudentAge() {
		List<Student> list1 = StudentsRepository.getAllStudents();
		list1.forEach(s -> System.out.println(s.getFirstName() + " : "+ s.getAge()));
	}
	
	public static void main(String[] args) {
		studentInfo.accept(StudentsRepository.getAllStudents().get(1));
		System.out.println("****************************************");
		studentFirstName.accept(StudentsRepository.getAllStudents().get(2));
		System.out.println("****************************************");
		studentInfo.andThen(studentFirstName).accept(StudentsRepository.getAllStudents().get(1));
		System.out.println("****************************************");
		studentsInfo.accept("Ganesh", 20);
		System.out.println("****************************************");
		//pritStudentName();
		pritStudentAge();
	}

}
