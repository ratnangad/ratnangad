package java8;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class StreamExample2 {

	public static void main(String[] args) {
		List<Integer> list = new ArrayList<>(Arrays.asList(1,2,3,4,5,1,2,3,4,5));
		
		//list = list.stream().filter(e -> e>3).filter(e -> e % 2 ==0).collect(Collectors.toList());
		Map<Integer, Integer> map= list.stream().map(e -> e*e).distinct().collect(Collectors.toMap(e -> e, e -> e*e));
		System.out.println(map);
		
	}

}
