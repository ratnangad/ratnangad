package java8;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Test {

	public static void main(String[] args) {
		List<Student> studentList = StudentsRepository.getAllStudents();
		Map<String, Student> studentMap = studentList.stream().filter(s -> s.getAge() > 16).collect(Collectors.toMap(Student::getFirstName, Student -> Student));
		//System.out.println(studentList.stream().collect(Collectors.maxBy(Comparator.comparing(Student::getHeight))));
		System.out.println(studentList.stream().sorted((a,b) -> (int)(a.getAge() - b.getAge())).collect(Collectors.toList()));
	}

}
