package java8;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

public class FunctionExample {
	
	static Function<String, String> f1 = name -> name.toUpperCase();
	static Function<String, Integer> f2 = name -> name.length();
	static Function<String, String> f3 = name -> name.concat("shaha");
	static Function<List<Student>, Map<String, Integer>> studentMap = studentList -> { 
		Map<String, Integer> stdMap = new HashMap<>();
		studentList.forEach(student -> {
			stdMap.put(student.getFirstName(), student.getAge());
		});
		return stdMap;
	};

	public static void main(String[] args) {
		System.out.println(f1.apply("Ganesh"));
		System.out.println(f2.apply("Ganesh"));
		System.out.println(f1.andThen(f3).apply("Ganesh"));
		System.out.println(f1.compose(f3).apply("Ganesh"));
		
		List<Student> students = StudentsRepository.getAllStudents();
		System.out.println(studentMap.apply(students));
	}

}
