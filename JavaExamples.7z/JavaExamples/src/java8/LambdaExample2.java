package java8;

import java.util.ArrayList;
import java.util.List;

public class LambdaExample2 {

	public static void main(String[] args) {
		List<String> list = new ArrayList<>();
		list.add("One");
		list.add("Two");
		list.add("Three");
		list.add("Four");
		list.add("Five");
		list.forEach(
				(str) -> System.out.println(str)
				);
	}

}
