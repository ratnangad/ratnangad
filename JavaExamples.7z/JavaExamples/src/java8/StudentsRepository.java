package java8;

import java.util.Arrays;
import java.util.List;

public class StudentsRepository {
	
	  public static List<Student> getAllStudents() {
		  Student s1 = new Student("Ganesh", "Shaha", 18, 165, "male");
		  Student s2 = new Student("Mahesh", "Mane", 17, 160,"male");
		  Student s3 = new Student("Riddhi", "Pardeshi", 16, 140,"female");
		  Student s4 = new Student("Sachin", "Pati", 18, 146, "male");
		  Student s5 = new Student("Dinesh", "Gawali", 17, 169, "male");
		  Student s6 = new Student("Swara", "Shaha", 16, 151, "female");
		  return Arrays.asList(s1,s2,s3,s4,s5,s6);
	  }

}
