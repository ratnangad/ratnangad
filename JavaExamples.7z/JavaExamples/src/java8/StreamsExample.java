package java8;

import java.util.Arrays;
import java.util.HashMap;
import java.util.IntSummaryStatistics;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class StreamsExample {

	public static void main(String[] args) {
		long count = 0;
		List<String> strings = Arrays.asList("abc", "", "bc", "efg", "abcd","", "jkl");
		count = strings.stream().filter(str -> str.isEmpty()).count();
		System.out.println("Empty Strings : "+count);
		
		count = strings.stream().filter(str -> str.length() == 3).count();
		System.out.println("Strings with 3 chars : "+count);
		
		List<String> filterStr = strings.stream().filter(str -> !str.isEmpty()).collect(Collectors.toList());
		System.out.println("NonEmpty List: " + filterStr);
		
		String mergeString = strings.stream().filter(str -> !str.isEmpty()).collect(Collectors.joining(","));
		System.out.println("NonEmpty List: " + mergeString);
		
		List<Integer> numbers = Arrays.asList(3, 2, 2, 3, 7, 3, 5);
		List<Integer> squaresList = numbers.stream().map( i ->i*i).distinct().collect(Collectors.toList());
	    System.out.println("Squares List: " + squaresList);
	    //squaresList.forEach(x -> System.out.println(x));
	      
	    List<Integer> integers = Arrays.asList(1,2,13,4,15,6,17,8,19);
	    IntSummaryStatistics stats = integers.stream().mapToInt(x -> x).summaryStatistics();
	    
	    System.out.println("Stats Max : " + stats.getMax());
	    System.out.println("Lowest number in List : " + stats.getMin());
	    System.out.println("Sum of all numbers : " + stats.getSum());
	    System.out.println("Average of all numbers : " + stats.getAverage());
	    
	    System.out.println("Random Numbers: ");
	    Random random = new Random();
	    //random.ints().limit(10).sorted().forEach(System.out::println);
	    
	    count = strings.parallelStream().filter(string -> string.isEmpty()).count();
	    System.out.println("Empty Strings: " + count);
	    
	    
	    Map<String, Integer> items = new HashMap<>();
		items.put("A", 10);
		items.put("B", 20);
		items.put("C", 30);
		items.put("D", 40);
		items.put("E", 50);
		items.put("F", 60);
		
		items.forEach((k,v) -> {
			System.out.println("Key: " + v);
			System.out.println("Value :" + v);
		});
	}

}
