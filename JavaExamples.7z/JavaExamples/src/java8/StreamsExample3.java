package java8;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

public class StreamsExample3 {

	public static void main(String[] args) {
		List<Student> studentList = StudentsRepository.getAllStudents();
		Map<String, Student> studentMap = studentList.stream()
										.filter(s -> s.getHeight() > 160)
										.filter(s -> s.getGender().equalsIgnoreCase("male"))
										.collect(Collectors.toMap(Student::getFirstName, Student -> Student));
		System.out.println(studentMap);
		
		List<String> studentNameInUpperCase = studentList.stream()
											.map(Student::getFirstName)
											.map(String::toUpperCase)
											.collect(Collectors.toList());
		System.out.println("studentNameInUpperCase: "+studentNameInUpperCase);
		
		
		Student studentByMaxHeight = studentList.stream()
							.collect(Collectors.maxBy(Comparator.comparing(Student::getHeight))).get();
		System.out.println("studentByMaxHeight: "+studentByMaxHeight.getFirstName());
		
				
		List<String> streamLimitExample = studentList.stream()
										.limit(2)
										.map(Student::getFirstName)
										.collect(Collectors.toList());
		System.out.println("streamLimitExample: "+streamLimitExample);
		
		List<String> streamSkipExample = studentList.stream()
				.skip(2)
				.map(Student::getFirstName)
				.collect(Collectors.toList());
		System.out.println("streamSkipExample: "+streamSkipExample);

	
		System.out.println("Sorted By Age" + studentList.stream().sorted((a,b) -> (int)(a.getAge() - b.getAge())).collect(Collectors.toList()));
	}

}
