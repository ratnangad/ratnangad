package designpatterns.factorypattern;

public class CommercialPlan extends Plan {

	@Override
	public void getRate() {
		rate = 9.5;
	}

}
