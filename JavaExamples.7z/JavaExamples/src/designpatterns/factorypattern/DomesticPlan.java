package designpatterns.factorypattern;

public class DomesticPlan extends Plan {

	@Override
	public void getRate() {
		rate = 5.5;
	}

}
