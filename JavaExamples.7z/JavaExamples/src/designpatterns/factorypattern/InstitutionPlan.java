package designpatterns.factorypattern;

public class InstitutionPlan extends Plan {

	@Override
	public void getRate() {
		rate = 7.5;
	}

}
