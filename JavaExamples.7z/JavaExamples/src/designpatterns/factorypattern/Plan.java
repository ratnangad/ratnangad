package designpatterns.factorypattern;

public abstract class Plan {
	protected double rate;
	public abstract void getRate();
	public void canculateBill(int units) {
		System.out.println("Bill is :" + units * rate);
	}
}
