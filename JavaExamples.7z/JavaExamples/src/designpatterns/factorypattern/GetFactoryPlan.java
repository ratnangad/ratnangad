package designpatterns.factorypattern;

public class GetFactoryPlan {
	public Plan getPlan(String planName) {
		if (planName.equalsIgnoreCase("Domestic"))
			return new DomesticPlan();
		else if (planName.equalsIgnoreCase("Commerical"))
			return new CommercialPlan();
		else if (planName.equalsIgnoreCase("Institution"))
			return new InstitutionPlan();
		else
			return null;
	}
}
