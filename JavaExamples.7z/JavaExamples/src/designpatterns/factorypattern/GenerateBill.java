package designpatterns.factorypattern;

public class GenerateBill {

	public static void main(String[] args) {
		GetFactoryPlan planFactory = new GetFactoryPlan();
		Plan plan = planFactory.getPlan("Commerical");
		plan.getRate();
		plan.canculateBill(5);
	}

}
