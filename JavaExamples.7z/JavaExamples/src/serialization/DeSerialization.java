package serialization;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.List;

public class DeSerialization {

	public static void main(String[] args) {
			
			try {
				FileInputStream fileInputStream = new FileInputStream("employee.txt");
				ObjectInputStream ois = new ObjectInputStream(fileInputStream);
				Employee employee = (Employee) ois.readObject();
				ois.close();		
				fileInputStream.close();
				System.out.println(employee.getEmpID());
				System.out.println(employee.getEmpName());
				System.out.println(employee.getEmpDept());
			} catch (ClassNotFoundException | IOException  e ) {
				e.printStackTrace();
			}
	}

}
