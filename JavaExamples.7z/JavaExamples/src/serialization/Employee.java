package serialization;

import java.io.Serializable;

public class Employee implements Serializable {

	//private static final long serialVersionUID = 2L;
	
	int empID;
	String empName;
	static String empDept;
	
	public int getEmpID() {
		return empID;
	}
	public void setEmpID(int empID) {
		this.empID = empID;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpDept() {
		return empDept;
	}
	public void setEmpDept(String empDept) {
		this.empDept = empDept;
	}
	
	
	
}
