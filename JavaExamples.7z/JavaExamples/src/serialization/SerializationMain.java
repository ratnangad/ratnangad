package serialization;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class SerializationMain {
	public static void main(String args[]) {
		Employee emp = new Employee();
		  emp.setEmpID(10);
		  emp.setEmpName("Ratnangad");
		  Employee.empDept = "Devlopment";
		  try
		  {
			  FileOutputStream fileOut = new FileOutputStream("employee.txt");
			  ObjectOutputStream outStream = new ObjectOutputStream(fileOut);
			  outStream.writeObject(emp);
			  outStream.close();
			  fileOut.close();
		  } catch(IOException i) {
			  i.printStackTrace();
		  }
	}
}
