package enumExam;

public enum Days {
	MONDAY,
	TUESDAY,
	WEDNESDAY,
	THUSDAY,
	FRIDAY,
	SATURDAY,
	SUNDAY;
	private Days() {
		System.out.println("This is constructor");
	}
	
}


