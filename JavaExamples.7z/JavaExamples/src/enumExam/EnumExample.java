package enumExam;

public class EnumExample {

	public static void main(String[] args) {
		System.out.println(Days.SATURDAY);
		
		System.out.println(Direction.NORTH);
		System.out.println(Direction.NORTH.getAngle());
		System.out.println(Direction.WEST.getDirection());
	}

}
