class Test {
	static {
		System.out.println("line 5");
		initialize();
	}

	private static int sum;

	public static int getSum() {
		System.out.println("line 14");
		initialize();
		System.out.println("line 16");
		return sum;
	}

	private static boolean initialized = true;
	private static int val  = 75;


	private static void initialize() {
		System.out.println("line 24" + initialized);
		System.out.println("line @ : " + val);
		if (initialized) {
			for (int i = 0; i < 5; i++)
				sum += i;
			initialized = false;
			val = 80;
		}
	}

	public static void main(String[] args) {
		System.out.println(Test.getSum());
	}
}